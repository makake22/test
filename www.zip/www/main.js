let a = 2
let b = 'babka vadima dyra ebanaya'

if (a == 2);

console.log(b)
